<?php if ( is_active_sidebar( 'shop' ) ) {
	dynamic_sidebar( 'shop' );
}
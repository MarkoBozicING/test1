<div class="latest-news-loop-with-img">
	<div class="wrap">
		<div class="img">
			<a href="<?php the_permalink(); ?>">
				<img src="<?php the_post_thumbnail_url('post-350-220'); ?>" />
			</a>
		</div>
		<div class="meta">
			<div class="meta-middle title heading-font">
				<a href="<?php the_permalink(); ?>">
					<?php the_title(); ?>
				</a>
			</div>
		</div>
	</div>
</div>
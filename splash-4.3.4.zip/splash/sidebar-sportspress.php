<?php if ( is_active_sidebar( 'sportspress' ) ) { ?>

	<div class="stm-sportspress-sidebar">
		<?php dynamic_sidebar( 'sportspress' ); ?>
	</div>

<?php }
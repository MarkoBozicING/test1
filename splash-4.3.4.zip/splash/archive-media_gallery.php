<?php get_header();

get_template_part('partials/global/media-archive');

get_footer();